﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MovieSite.DataLayer.Migrations
{
    public partial class mig_edit_id : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Movies",
                columns: table => new
                {
                    MovieId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title_id = table.Column<string>(nullable: true),
                    Title = table.Column<string>(maxLength: 300, nullable: true),
                    OriginalTitle = table.Column<string>(maxLength: 300, nullable: true),
                    Year = table.Column<int>(nullable: true),
                    DatePublished = table.Column<DateTime>(nullable: true),
                    Genre = table.Column<string>(maxLength: 200, nullable: true),
                    Duration = table.Column<int>(nullable: true),
                    Country = table.Column<string>(maxLength: 200, nullable: true),
                    Language = table.Column<string>(maxLength: 200, nullable: true),
                    Director = table.Column<string>(maxLength: 300, nullable: true),
                    Writer = table.Column<string>(maxLength: 300, nullable: true),
                    ProductionCompany = table.Column<string>(maxLength: 300, nullable: true),
                    Actors = table.Column<string>(maxLength: 800, nullable: true),
                    Description = table.Column<string>(maxLength: 800, nullable: true),
                    AvgVote = table.Column<float>(nullable: true),
                    Votes = table.Column<int>(nullable: true),
                    Budget = table.Column<string>(maxLength: 200, nullable: true),
                    USAGross = table.Column<string>(maxLength: 200, nullable: true),
                    WorldwideGrossIncome = table.Column<string>(maxLength: 200, nullable: true),
                    Metascore = table.Column<int>(nullable: true),
                    ReviewsFromUsers = table.Column<int>(nullable: true),
                    ReviewsFromCritics = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Movies", x => x.MovieId);
                });

            migrationBuilder.CreateTable(
                name: "Names",
                columns: table => new
                {
                    NameId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name_id = table.Column<string>(nullable: true),
                    StageName = table.Column<string>(maxLength: 300, nullable: true),
                    BirthName = table.Column<string>(maxLength: 300, nullable: true),
                    Height = table.Column<int>(nullable: false),
                    Bio = table.Column<string>(maxLength: 700, nullable: true),
                    DateOfBirth = table.Column<DateTime>(nullable: false),
                    PlaceOfBirth = table.Column<string>(maxLength: 300, nullable: true),
                    DeathDetails = table.Column<string>(maxLength: 700, nullable: true),
                    DateOfDeath = table.Column<DateTime>(nullable: false),
                    PlaceOfDeath = table.Column<string>(maxLength: 300, nullable: true),
                    ReasonOfDeath = table.Column<string>(maxLength: 500, nullable: true),
                    SpousesName = table.Column<string>(maxLength: 300, nullable: true),
                    Spouses = table.Column<int>(nullable: false),
                    Divorces = table.Column<int>(nullable: false),
                    SpousesWithChildren = table.Column<int>(nullable: false),
                    Children = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Names", x => x.NameId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(maxLength: 200, nullable: false),
                    Email = table.Column<string>(maxLength: 200, nullable: false),
                    Password = table.Column<string>(maxLength: 200, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    UserAvatar = table.Column<string>(maxLength: 200, nullable: true),
                    RegisterDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "MovieNamePrinciples",
                columns: table => new
                {
                    MNPrincpleId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title_id = table.Column<string>(nullable: true),
                    Name_id = table.Column<string>(nullable: true),
                    Ordering = table.Column<int>(nullable: false),
                    Category = table.Column<string>(maxLength: 200, nullable: true),
                    Job = table.Column<string>(maxLength: 200, nullable: true),
                    Characters = table.Column<string>(maxLength: 300, nullable: true),
                    MovieId = table.Column<int>(nullable: true),
                    NameId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MovieNamePrinciples", x => x.MNPrincpleId);
                    table.ForeignKey(
                        name: "FK_MovieNamePrinciples_Movies_MovieId",
                        column: x => x.MovieId,
                        principalTable: "Movies",
                        principalColumn: "MovieId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MovieNamePrinciples_Names_NameId",
                        column: x => x.NameId,
                        principalTable: "Names",
                        principalColumn: "NameId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MovieComments",
                columns: table => new
                {
                    CommentId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(nullable: false),
                    MovieId = table.Column<int>(nullable: false),
                    Comment = table.Column<string>(maxLength: 700, nullable: false),
                    CreateDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MovieComments", x => x.CommentId);
                    table.ForeignKey(
                        name: "FK_MovieComments_Movies_MovieId",
                        column: x => x.MovieId,
                        principalTable: "Movies",
                        principalColumn: "MovieId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MovieComments_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MovieVotes",
                columns: table => new
                {
                    VoteId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MovieId = table.Column<int>(nullable: false),
                    UserId = table.Column<int>(nullable: false),
                    Vote = table.Column<int>(nullable: false),
                    VoteDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MovieVotes", x => x.VoteId);
                    table.ForeignKey(
                        name: "FK_MovieVotes_Movies_MovieId",
                        column: x => x.MovieId,
                        principalTable: "Movies",
                        principalColumn: "MovieId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MovieVotes_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SavedMovies",
                columns: table => new
                {
                    SavedMovieUserId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(nullable: false),
                    MovieId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SavedMovies", x => x.SavedMovieUserId);
                    table.ForeignKey(
                        name: "FK_SavedMovies_Movies_MovieId",
                        column: x => x.MovieId,
                        principalTable: "Movies",
                        principalColumn: "MovieId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SavedMovies_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_MovieComments_MovieId",
                table: "MovieComments",
                column: "MovieId");

            migrationBuilder.CreateIndex(
                name: "IX_MovieComments_UserId",
                table: "MovieComments",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_MovieNamePrinciples_MovieId",
                table: "MovieNamePrinciples",
                column: "MovieId");

            migrationBuilder.CreateIndex(
                name: "IX_MovieNamePrinciples_NameId",
                table: "MovieNamePrinciples",
                column: "NameId");

            migrationBuilder.CreateIndex(
                name: "IX_MovieVotes_MovieId",
                table: "MovieVotes",
                column: "MovieId");

            migrationBuilder.CreateIndex(
                name: "IX_MovieVotes_UserId",
                table: "MovieVotes",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SavedMovies_MovieId",
                table: "SavedMovies",
                column: "MovieId");

            migrationBuilder.CreateIndex(
                name: "IX_SavedMovies_UserId",
                table: "SavedMovies",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MovieComments");

            migrationBuilder.DropTable(
                name: "MovieNamePrinciples");

            migrationBuilder.DropTable(
                name: "MovieVotes");

            migrationBuilder.DropTable(
                name: "SavedMovies");

            migrationBuilder.DropTable(
                name: "Names");

            migrationBuilder.DropTable(
                name: "Movies");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
