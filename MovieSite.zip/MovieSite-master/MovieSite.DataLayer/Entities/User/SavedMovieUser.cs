﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace MovieSite.DataLayer.Entities.User
{
    public class SavedMovieUser
    {
        [Key]
        public int SavedMovieUserId { get; set; }

        public int UserId { get; set; }

        public int MovieId { get; set; }


        public User User { get; set; }

        public Movie.Movie Movie { get; set; }

    }
}
