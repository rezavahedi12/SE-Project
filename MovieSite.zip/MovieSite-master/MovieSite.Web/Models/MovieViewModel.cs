﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Web.Models
{
    public class MovieViewModel
    {
        public string Title_id { get; set; }

        public string? Title { get; set; }

        public string? OriginalTitle { get; set; }

        public int? Year { get; set; }

        [DataType(DataType.Date)]
        public DateTime? DatePublished { get; set; }

        public string? Genre { get; set; }

        public int? Duration { get; set; }

        public string? Country { get; set; }

        public string? Language { get; set; }

        public string? Director { get; set; }

        public string? Writer { get; set; }

        public string? ProductionCompany { get; set; }
        public string? Actors { get; set; }

        public string? Description { get; set; }

        public float? AvgVote { get; set; }

        public int? Votes { get; set; }

        public string? Budget { get; set; }

        public string? USAGross { get; set; }

        public string? WorldwideGrossIncome { get; set; }

        public int? Metascore { get; set; }

        public int? ReviewsFromUsers { get; set; }

        public int? ReviewsFromCritics { get; set; }
    }
}
