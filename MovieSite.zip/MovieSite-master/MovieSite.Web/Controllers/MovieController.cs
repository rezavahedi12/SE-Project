﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieSite.Core.Services.Interfaces;
using MovieSite.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Web.Controllers
{
    public class MovieController : Controller
    {

        private IMovieService _movieService;

        public MovieController(IMovieService movieService)
        {
            _movieService = movieService;
        }

        //movies
        [Produces("application/json")]
        [HttpGet("movies")]
        public async Task<IActionResult> Index(int count = 10, string titleFilter = "")
        {
            try
            {
                List <ShowMovieList> movies = await _movieService.GetMovies(count, titleFilter);
                return Json(movies);
            }
            catch
            {
                return BadRequest();
            }
        }

        //movies/id
        [Produces("application/json")]
        [HttpGet("movies/{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var movie = await _movieService.GetMovieById(id);
                return Json(movie);
            }

            catch
            {
                return BadRequest();
            }
        }





       
    }
}
