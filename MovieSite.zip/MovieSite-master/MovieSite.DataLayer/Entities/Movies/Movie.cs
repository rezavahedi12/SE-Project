﻿using MovieSite.DataLayer.Entities.User;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace MovieSite.DataLayer.Entities.Movie
{
    public class Movie
    {
        [Key]
        public int MovieId { get; set; }

        public string Title_id { get; set; }


        [MaxLength(300)]
        public string? Title { get; set; }

        [MaxLength(300)]
        public string? OriginalTitle { get; set; }

        public int? Year { get; set; }

        [DataType(DataType.Date)]
        public DateTime? DatePublished { get; set; }

        [MaxLength(200)]
        public string? Genre { get; set; } 

        public int? Duration { get; set; }

        [MaxLength(200)]
        public string? Country { get; set; }

        [MaxLength(200)]
        public string? Language { get; set; }

        [MaxLength(300)]
        public string? Director { get; set; }

        [MaxLength(300)]
        public string? Writer { get; set; }

        [MaxLength(300)]
        public string? ProductionCompany { get; set; }

        [MaxLength(800)]
        public string? Actors { get; set; }

        [MaxLength(800)]
        public string? Description { get; set; }

        public float? AvgVote { get; set; }

        public int? Votes { get; set; }

        [MaxLength(200)]
        public string? Budget { get; set; }

        [MaxLength(200)]
        public string? USAGross { get; set; }

        [MaxLength(200)]
        public string? WorldwideGrossIncome { get; set; }

        public int? Metascore { get; set; }

        public int? ReviewsFromUsers { get; set; }

        public int? ReviewsFromCritics { get; set; }


        #region Relations

        public List<MovieVote> MovieVotes { get; set; }
        public List<MovieComment> MovieComments { get; set; }

        public List<MovieNamePrinciple> MovieNamePrinciples { get; set; }
        public List<SavedMovieUser> SavedMovies { get; set; }
        #endregion

    }
}
