using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDataReader;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieSite.DataLayer.Entities.Movie;
using MovieSite.Web.Services.Interfaces;

namespace MovieSite.Web.Pages.Admin.Names
{
    public class AddNameModel : PageModel
    {
        private INameService _nameService;

        public AddNameModel(INameService nameService)
        {
            _nameService = nameService;
        }

        [BindProperty]
        public List<Name> Names { get; set; }
        public void OnGet()
        {
            Names = new List<Name>();
        }


        public IActionResult OnPost(IFormFile excelFile)
        {
            string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", excelFile.FileName);
            using (var stream = System.IO.File.Create(path))
            {
                excelFile.CopyTo(stream);


            }

            using (var stream = System.IO.File.Open(path, FileMode.Open, FileAccess.Read))
            {
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read();
                    if (reader.GetValue(0).ToString() == "imdb_name_id")
                    {
                        while (reader.Read())
                        {

                            Name name = new Name
                            {
                                Name_id = reader.GetValue(0).ToString(),
                                StageName = reader.GetValue(1)?.ToString(),
                                BirthName = reader.GetValue(2)?.ToString(),
                                Height = Isnull(reader.GetValue(3)?.ToString()),
                                Bio = reader.GetValue(4)?.ToString(),
                                BirthDetails = reader.GetValue(5)?.ToString(),
                                DateOfBirth = ConvertDate(reader.GetValue(6)?.ToString()),
                                PlaceOfBirth = reader.GetValue(7)?.ToString(),
                                DeathDetails = reader.GetValue(8)?.ToString(),
                                DateOfDeath = ConvertDate(reader.GetValue(9)?.ToString()),
                                PlaceOfDeath = reader.GetValue(10)?.ToString(),
                                ReasonOfDeath = reader.GetValue(11)?.ToString(),
                                SpousesName = reader.GetValue(12)?.ToString(),
                                Spouses = Isnull(reader.GetValue(13)?.ToString()),
                                Divorces = Isnull(reader.GetValue(14)?.ToString()),
                                SpousesWithChildren = Isnull(reader.GetValue(15)?.ToString()),
                                Children = Isnull(reader.GetValue(16)?.ToString()),
                            };
                            _nameService.AddName(name);
                            Names.Add(name);


                        }
                    }
                }
            }

            return Page();
        }


        private DateTime? ConvertDate(string date)
        {
            try
            {
                string[] formats = { "MM/dd/yyyy HH:mm:ss", "yyyy-MM-dd" };
                return DateTime.ParseExact(date, formats, CultureInfo.InvariantCulture, DateTimeStyles.None);
            }
            catch
            {
                return null;
            }

        }

        private int? Isnull(string val)
        {
            if (val == null)
                return null;
            else
            {
                return int.Parse(val);
            }
        }
    }
}
