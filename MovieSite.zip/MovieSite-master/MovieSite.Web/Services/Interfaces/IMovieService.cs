﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MovieSite.DataLayer.Entities.Movie;
using MovieSite.Web.Models;

namespace MovieSite.Core.Services.Interfaces
{
    public interface IMovieService
    {
        void AddMovie(Movie movie);

        Task<List<ShowMovieList>> GetAllMovies();

        Task<List<ShowMovieList>> GetMovies(int count, string titleFilter);

        Task<Movie> GetMovieById(int id);

        Task<List<ShowMovieList>> SearchMovieByTitleList(string title);
    }
}
