using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDataReader;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieSite.DataLayer.Entities.Movie;
using MovieSite.Web.Services.Interfaces;

namespace MovieSite.Web.Pages.Admin.Names
{
    public class AddMovieNamePrincipleModel : PageModel
    {
        private IMovieNamePrincipleService _principleService;

        public AddMovieNamePrincipleModel(IMovieNamePrincipleService principleService)
        {
            _principleService = principleService;
        }

        [BindProperty]
        public List<MovieNamePrinciple> Principles { get; set; }
        public void OnGet()
        {
            Principles = new List<MovieNamePrinciple>();
        }

        public IActionResult OnPost(IFormFile excelFile)
        {
            string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", excelFile.FileName);
            using (var stream = System.IO.File.Create(path))
            {
                excelFile.CopyTo(stream);


            }

            using (var stream = System.IO.File.Open(path, FileMode.Open, FileAccess.Read))
            {
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read();
                    if (reader.GetValue(0).ToString() == "imdb_title_id")
                    {
                        while (reader.Read())
                        {
                            MovieNamePrinciple principle = new MovieNamePrinciple()
                            {
                                Title_id = reader.GetValue(0).ToString(),
                                Ordering = Isnull(reader.GetValue(1)?.ToString()),
                                Name_id = reader.GetValue(2).ToString(),
                                Category = reader.GetValue(3)?.ToString(),
                                Job = reader.GetValue(4)?.ToString(),
                                Characters = reader.GetValue(5)?.ToString(),
                            };
                            _principleService.AddMovieNamePrinciple(principle);
                            Principles.Add(principle);

                        }
                    }
                }
            }

            return Page();
        }


        private int? Isnull(string val)
        {
            if (val == null)
                return null;
            else
            {
                return int.Parse(val);
            }
        }
    }
}
