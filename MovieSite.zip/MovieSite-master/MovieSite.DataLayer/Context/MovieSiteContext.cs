﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MovieSite.DataLayer.Entities.Movie;
using MovieSite.DataLayer.Entities.User;

namespace MovieSite.DataLayer.Context
{
    public class IMovieSiteContext : IdentityDbContext
    {
        public IMovieSiteContext(DbContextOptions<IMovieSiteContext> options) : base(options)
        {
        }

        #region user
        //public DbSet<User> Users { get; set; }

        public DbSet<SavedMovieUser> SavedMovies { get; set; }

        public DbSet<RefreshToken> RefreshTokens { get; set; }

        #endregion

        #region movie
        public DbSet<Movie> Movies { get; set; }

        public DbSet<Name> Names { get; set; }

        public DbSet<MovieComment> MovieComments { get; set; }

        public DbSet<MovieNamePrinciple> MovieNamePrinciples { get; set; }

        public DbSet<MovieVote> MovieVotes { get; set; }

        #endregion
    }
}
