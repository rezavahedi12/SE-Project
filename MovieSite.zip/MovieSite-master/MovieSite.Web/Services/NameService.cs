﻿using MovieSite.DataLayer.Context;
using MovieSite.DataLayer.Entities.Movie;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Web.Services
{
    public class NameService : Interfaces.INameService
    {
        private IMovieSiteContext _context;

        public NameService(IMovieSiteContext context)
        {
            _context = context;
        }

        public void AddName(Name name)
        {
            _context.Names.Add(name);
            _context.SaveChanges();
        }
    }
}
