﻿using MovieSite.DataLayer.Context;
using MovieSite.DataLayer.Entities.Movie;
using MovieSite.Web.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Web.Services
{
    public class MovieNamePrincipleService:IMovieNamePrincipleService
    {
        private IMovieSiteContext _context;

        public MovieNamePrincipleService(IMovieSiteContext context)
        {
            _context = context;
        }

        public void AddMovieNamePrinciple(MovieNamePrinciple principle)
        {
            _context.MovieNamePrinciples.Add(principle);
            _context.SaveChanges();
        }
    }
}
