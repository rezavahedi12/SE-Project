﻿using Microsoft.EntityFrameworkCore;
using MovieSite.DataLayer.Context;
using MovieSite.DataLayer.Entities.Movie;
using MovieSite.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieSite.Core.Services
{
    public class MovieService : Interfaces.IMovieService
    {
        private IMovieSiteContext _context;

        public MovieService(IMovieSiteContext context)
        {
            _context = context;
        }

        public void AddMovie(Movie movie)
        {
            _context.Movies.Add(movie);
            _context.SaveChanges();


        }

        public async Task<List<ShowMovieList>> GetAllMovies()
        {
            return await _context.Movies.OrderByDescending(m => m.Year)
                .ThenBy(m => m.Title)
                .Select(m => new ShowMovieList()
                {
                    MovieId = m.MovieId,
                    Title_id = m.Title_id,
                    Title = m.Title,
                    OriginalTitle = m.OriginalTitle,
                    Year = m.Year,
                    DatePublished = m.DatePublished,
                    Genre = m.Genre,
                    Duration = m.Duration,
                    Country = m.Country,
                    Language = m.Language,
                    Director = m.Director,
                    Writer = m.Writer,
                    ProductionCompany = m.ProductionCompany,
                    Actors = m.Actors,
                    Description = m.Description,
                    AvgVote = m.AvgVote,
                    Votes = m.Votes,
                    Budget = m.Budget,
                    USAGross = m.USAGross,
                    Metascore = m.Metascore,
                    ReviewsFromUsers = m.ReviewsFromUsers,
                    ReviewsFromCritics = m.ReviewsFromCritics

                }).ToListAsync();
        }

        public async Task<Movie> GetMovieById(int id)
        {
            return await _context.Movies.FirstOrDefaultAsync(m => m.MovieId == id);
        }

        public async Task<List<ShowMovieList>> GetMovies(int count, string titleFilter)
        {
            return await _context.Movies.Where(m => m.Title.Contains(titleFilter) || m.OriginalTitle.Contains(titleFilter)).OrderByDescending(m => m.Year)
                .ThenBy(m => m.Title)
                .Select(m => new ShowMovieList()
                {
                    MovieId = m.MovieId,
                    Title_id = m.Title_id,
                    Title = m.Title,
                    OriginalTitle = m.OriginalTitle,
                    Year = m.Year,
                    DatePublished = m.DatePublished,
                    Genre = m.Genre,
                    Duration = m.Duration,
                    Country = m.Country,
                    Language = m.Language,
                    Director = m.Director,
                    Writer = m.Writer,
                    ProductionCompany = m.ProductionCompany,
                    Actors = m.Actors,
                    Description = m.Description,
                    AvgVote = m.AvgVote,
                    Votes = m.Votes,
                    Budget = m.Budget,
                    USAGross = m.USAGross,
                    Metascore = m.Metascore,
                    ReviewsFromUsers = m.ReviewsFromUsers,
                    ReviewsFromCritics = m.ReviewsFromCritics

                }).Take(count).ToListAsync();
        }

        public async Task<List<ShowMovieList>> SearchMovieByTitleList(string title)
        {
            return await _context.Movies.Where(m => m.Title.Contains(title) || m.OriginalTitle.Contains(title)).OrderByDescending(m => m.Year)
                .ThenBy(m => m.Title)
                .Select(m => new ShowMovieList()
                {
                    MovieId = m.MovieId,
                    Title_id = m.Title_id,
                    Title = m.Title,
                    OriginalTitle = m.OriginalTitle,
                    Year = m.Year,
                    DatePublished = m.DatePublished,
                    Genre = m.Genre,
                    Duration = m.Duration,
                    Country = m.Country,
                    Language = m.Language,
                    Director = m.Director,
                    Writer = m.Writer,
                    ProductionCompany = m.ProductionCompany,
                    Actors = m.Actors,
                    Description = m.Description,
                    AvgVote = m.AvgVote,
                    Votes = m.Votes,
                    Budget = m.Budget,
                    USAGross = m.USAGross,
                    Metascore = m.Metascore,
                    ReviewsFromUsers = m.ReviewsFromUsers,
                    ReviewsFromCritics = m.ReviewsFromCritics

                }).ToListAsync();
        }
    }
}
