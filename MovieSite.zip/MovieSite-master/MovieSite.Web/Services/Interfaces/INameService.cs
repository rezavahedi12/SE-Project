﻿using MovieSite.DataLayer.Entities.Movie;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Web.Services.Interfaces
{
    public interface INameService
    {
        void AddName(Name name);
    }
}
