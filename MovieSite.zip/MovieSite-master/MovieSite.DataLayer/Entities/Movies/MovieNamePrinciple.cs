﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace MovieSite.DataLayer.Entities.Movie
{
    public class MovieNamePrinciple
    {
        [Key]
        public int MNPrincpleId { get; set; }

        public string Title_id { get; set; }

        public string Name_id{ get; set; }

        public int? Ordering { get; set; }

        [MaxLength(300)]
        public string? Category { get; set; }

        [MaxLength(300)]
        public string? Job { get; set; }

        [MaxLength(300)]
        public string? Characters { get; set; }

        #region relations

        public Movie Movie { get; set; }

        public Name Name { get; set; }


        #endregion
    }
}
