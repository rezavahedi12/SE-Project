using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDataReader;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieSite.Core.Services.Interfaces;
using MovieSite.DataLayer.Entities.Movie;

namespace MovieSite.Web.Pages.Admin.Movies

{
    public class AddMovieModel : PageModel
    {

        private IMovieService _movieService;

        public AddMovieModel(IMovieService movieService)
        {
            _movieService = movieService;
        }

        [BindProperty]
        public List<Movie> Movies { get; set; }
        public void OnGet()
        {
            Movies = new List<Movie>();
        }


        public IActionResult OnPost(IFormFile excelFile)
        {
            string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", excelFile.FileName);
            using (var stream = System.IO.File.Create(path))
            {
               excelFile.CopyTo(stream);


            }

            using (var stream = System.IO.File.Open(path, FileMode.Open, FileAccess.Read))
            {
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read();
                    if (reader.GetValue(0).ToString() == "imdb_title_id")
                    {
                        while (reader.Read())
                        {

                            Movie movie = new Movie
                            {
                                Title_id = reader.GetValue(0).ToString(),
                                Title = reader.GetValue(1)?.ToString(),
                                OriginalTitle = reader.GetValue(2)?.ToString(),
                                Year = int.Parse(reader.GetValue(3).ToString()),
                                DatePublished = ConvertDate(reader.GetValue(4).ToString()),
                                Genre = reader.GetValue(5)?.ToString(),
                                Duration = Isnull(reader.GetValue(6)?.ToString()),
                                Country = reader.GetValue(7)?.ToString(),
                                Language = reader.GetValue(8)?.ToString(),
                                Director = reader.GetValue(9)?.ToString(),
                                Writer = reader.GetValue(10)?.ToString(),
                                ProductionCompany = reader.GetValue(11)?.ToString(),
                                Actors = reader.GetValue(12)?.ToString(),
                                Description = reader.GetValue(13)?.ToString(),
                                AvgVote = float.Parse(reader.GetValue(14).ToString()),
                                Votes = Isnull(reader.GetValue(15)?.ToString()),
                                Budget = reader.GetValue(16)?.ToString(),
                                USAGross = reader.GetValue(17)?.ToString(),
                                WorldwideGrossIncome = reader.GetValue(18)?.ToString(),
                                Metascore = Isnull(reader.GetValue(19)?.ToString()),
                                ReviewsFromUsers = Isnull(reader.GetValue(20)?.ToString()),
                                ReviewsFromCritics = Isnull(reader.GetValue(21)?.ToString()),
                            };
                            _movieService.AddMovie(movie);
                            Movies.Add(movie);


                        }
                    }
                }
            }

            return Page();
    }


    private DateTime? ConvertDate(string date)
    {
        try
        {
            string[] formats = { "MM/dd/yyyy HH:mm:ss", "yyyy-MM-dd" };
            return DateTime.ParseExact(date, formats, CultureInfo.InvariantCulture, DateTimeStyles.None);
        }
        catch
        {
            return null;
        }

    }

    private int? Isnull(string val)
    {
        if (val == null)
            return null;
        else
        {
            return int.Parse(val);
        }
    }
}
}
