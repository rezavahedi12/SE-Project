﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace MovieSite.DataLayer.Entities.Movie
{
    public class MovieComment
    {
        [Key]
        public int CommentId { get; set; }

        public int UserId { get; set; }

        public int MovieId { get; set; }

        [Display(Name = "نظر")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        [MaxLength(700, ErrorMessage = "{0} نمی تواند بیشتر از {1} کاراکتر باشد .")]
        public string Comment { get; set; }
        public DateTime CreateDate { get; set; }

        public User.User User { get; set; }
        public Movie Movie { get; set; }

    }
}
