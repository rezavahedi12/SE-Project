﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace MovieSite.DataLayer.Entities.Movie
{
    public class MovieVote
    {
        [Key]
        public int VoteId { get; set; }
        [Required]
        public int MovieId { get; set; }
        [Required]
        public int UserId { get; set; }
        [Required]
        [Range(1, 5)]
        public int Vote { get; set; }
        public DateTime VoteDate { get; set; } = DateTime.Now;


        public User.User User { get; set; }
        public Movie Movie { get; set; }
    }
}
