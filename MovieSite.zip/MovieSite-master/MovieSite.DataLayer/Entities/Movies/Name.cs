﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using System.Text;

namespace MovieSite.DataLayer.Entities.Movie
{
    public class Name
    {
        [Key]
        public int NameId { get; set; }

        public string  Name_id { get; set; }

        [MaxLength(300)]
        public string? StageName { get; set; }

        [MaxLength(300)]
        public string? BirthName { get; set; }

        public int? Height { get; set; }

        public string? Bio { get; set; }

        [MaxLength(400)]
        public string? BirthDetails { get; set; }

        [DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        [MaxLength(400)]
        public string? PlaceOfBirth { get; set; }

        [MaxLength(400)]
        public string? DeathDetails { get; set; }

        [DataType(DataType.Date)]
        public DateTime? DateOfDeath { get; set; }

        [MaxLength(400)]
        public string? PlaceOfDeath { get; set; }

        [MaxLength(600)]
        public string? ReasonOfDeath { get; set; }

        [MaxLength(1000)]
        public string? SpousesName { get; set; }

        public int? Spouses { get; set; }

        public int? Divorces { get; set; }

        public int? SpousesWithChildren { get; set; }

        public int? Children { get; set; }

        #region relations

        public List<MovieNamePrinciple> MovieNamePrinciples { get; set; }


        #endregion

    }
}
